//
//  loginViewController.swift
//  zoneZeroApp
//
//  Created by Mahir Uslu on 5.02.2020.
//  Copyright © 2020 Mahir Uslu. All rights reserved.
//

import UIKit

class loginViewController: UIViewController {

    @IBOutlet weak var usernameText: UITextField!
    @IBOutlet weak var passwordText: UITextField!
    @IBOutlet weak var remindMeSwitch: UISwitch!
    @IBOutlet weak var promoteSwitch: UISwitch!
    @IBOutlet weak var signinButton: UIButton!
    @IBOutlet weak var promoteLabel: UILabel!
    
    @IBOutlet weak var signinBtn: UIButton!
    
    var finalUsername = ""
    var finalEmail = ""
    var finalPassword = ""
    
    
    
    @IBAction func signinBtn(_ sender: Any) {
        if (finalUsername != usernameText.text!){
           makeAlert(titleInput: "Error", messageInput: "Wrong username!")
        }else if (finalPassword != passwordText.text!){
           makeAlert(titleInput: "Error", messageInput: "Wrong password!")
        }else{
            performSegue(withIdentifier: "logintoTableviewVC", sender: self)
        }
    }
    
    func makeAlert(titleInput: String, messageInput:String) {
        let alert = UIAlertController(title: titleInput, message: messageInput, preferredStyle: UIAlertController.Style.alert)
        let okButton = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
        alert.addAction(okButton)
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func remindMeTapped(_ sender: Any) {
        if (remindMeSwitch.isOn){
            promoteSwitch.isHidden = false
            promoteLabel.isHidden = false
        }else{
            promoteSwitch.isHidden = true
            promoteLabel.isHidden = true
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
