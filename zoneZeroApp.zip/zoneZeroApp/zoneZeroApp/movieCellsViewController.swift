//
//  movieCellsViewController.swift
//  zoneZeroApp
//
//  Created by Mahir Uslu on 5.02.2020.
//  Copyright © 2020 Mahir Uslu. All rights reserved.
//

import UIKit

class movieCellsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    var movieList = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        movieList.append( "Intersellar")
        movieList.append( "Joker")
        movieList.append( "10 Things I hate about you")
        movieList.append( "The eternal sunshine of the spotless mind")
        movieList.append( "The godfather")
        movieList.append( "Scarface")
        movieList.append( "Iron Man")
        movieList.append( "The notebook")
        movieList.append( "Seven")
        movieList.append( "Once upon a time in Hollywood")
    
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.textLabel?.textColor = UIColor.darkGray
        cell.textLabel?.text = movieList[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        makeAlert(titleInput: movieList[indexPath.row], messageInput: "Perfect Movie")
    }
    
    func makeAlert(titleInput: String, messageInput:String) {
        let alert = UIAlertController(title: titleInput, message: messageInput, preferredStyle: UIAlertController.Style.alert)
        let okButton = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
        alert.addAction(okButton)
        self.present(alert, animated: true, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
