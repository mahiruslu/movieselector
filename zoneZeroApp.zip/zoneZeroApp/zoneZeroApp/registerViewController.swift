//
//  RegisterViewController.swift
//  zoneZeroApp
//
//  Created by Mahir Uslu on 5.02.2020.
//  Copyright © 2020 Mahir Uslu. All rights reserved.
//

import UIKit

class registerViewController: UIViewController {

    @IBOutlet weak var usernameText: UITextField!
    @IBOutlet weak var emailText: UITextField!
    @IBOutlet weak var passwordText: UITextField!
    @IBOutlet weak var repasswordText: UITextField!
    @IBAction func signupBtn(_ sender: Any) {
        if (usernameText.text!.count<4){
            makeAlert(titleInput: "Error", messageInput: "You have to type at least 4 character in username!")
         }else if (emailText.text!.count<4){
           makeAlert(titleInput: "Error", messageInput: "You have to type at least 4 character in email!")
        }else if (passwordText.text! != repasswordText.text! ||  passwordText.text!.count<4){
           makeAlert(titleInput: "Error", messageInput: "The passwords are not matches!")
        }else{
            UserDefaults.standard.set(emailText.text!, forKey: "email")
            UserDefaults.standard.set(usernameText.text!, forKey: "username")
            UserDefaults.standard.set(passwordText.text!, forKey: "password")
            
            
            storedusername = UserDefaults.standard.object(forKey: "username") as! String
            storedemail = UserDefaults.standard.object(forKey: "email") as! String
            storedpassword = UserDefaults.standard.object(forKey: "password") as! String
            
            performSegue(withIdentifier: "registertologinVC", sender: self)
        }
        
    }
    
    var storedusername = ""
    var storedemail = ""
    var storedpassword = ""
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! loginViewController
        vc.finalUsername = self.storedusername
        vc.finalEmail = self.storedemail
        vc.finalPassword = self.storedpassword
    }
    
    func makeAlert(titleInput: String, messageInput:String) {
        let alert = UIAlertController(title: titleInput, message: messageInput, preferredStyle: UIAlertController.Style.alert)
        let okButton = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
        alert.addAction(okButton)
        self.present(alert, animated: true, completion: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
